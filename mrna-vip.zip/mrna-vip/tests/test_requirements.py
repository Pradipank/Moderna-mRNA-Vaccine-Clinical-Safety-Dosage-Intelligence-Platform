"""One+ test per functional requirement.  Run from repo root:  python -m unittest discover -s tests -v
(Needs `python run_pipeline.py` to have been run once so outputs/ exists.)"""
import json
import os
import re
import shutil
import tempfile
import unittest

import numpy as np
import pandas as pd

from src import attention, data_pipeline as dp, report_generator as rg, risk_model as rm
from src.llm_clients import LLMClient, OfflineGroundedLLM
from src.rag_index import GuidelineIndex, chunk_text, count_tokens
from src.schemas import DISCLAIMER, ClinicalSafetyReport, ValidationError

RAW, BIO_T = "data/patient_records.csv", 7.0


def jload(p):
    with open(p) as f:
        return json.load(f)


class Module1(unittest.TestCase):
    def test_fr_1_1_missing_column_named(self):
        d = tempfile.mkdtemp(); p = os.path.join(d, "x.csv")
        pd.read_csv(RAW).drop(columns=["Biomarker_Level"]).to_csv(p, index=False)
        with self.assertRaises(dp.MissingColumnsError) as c:
            dp.load_raw(p)
        self.assertIn("Biomarker_Level", str(c.exception)); shutil.rmtree(d)

    def test_none_category_is_not_treated_as_missing(self):
        df = dp.load_raw(RAW)
        self.assertEqual((df.Prior_Reaction_History == "None").sum(), 291)
        self.assertEqual(df.Prior_Reaction_History.isnull().sum(), 17)

    def test_fr_1_2_imputation(self):
        clean, _, mode = dp.impute(dp.load_raw(RAW))
        self.assertEqual(int(clean.isnull().sum().sum()), 0); self.assertEqual(mode, "None")

    def test_fr_1_3_scaling_train_mean0_std1(self):
        tr, _ = rm.split(dp.load_raw(RAW)); tr, _, _ = dp.impute(tr)
        Z = rm.make_preprocessor().fit_transform(tr[rm.FEATURES])[:, :3]
        np.testing.assert_allclose(Z.mean(0), 0, atol=1e-8); np.testing.assert_allclose(Z.std(0), 1, atol=1e-8)

    def test_fr_1_4_split_reproducible_stratified(self):
        df = dp.load_raw(RAW); a, b = rm.split(df); c, _ = rm.split(df)
        self.assertEqual(list(a.Patient_ID), list(c.Patient_ID)); self.assertEqual(len(b), 100)
        self.assertAlmostEqual(a.Reaction_Score.mean(), b.Reaction_Score.mean(), delta=0.02)

    def test_fr_1_5_to_1_7_models_reports_serialized(self):
        m = jload("outputs/model_metrics.json")
        self.assertEqual(set(m["metrics"]), {"logistic_regression", "random_forest"})
        self.assertEqual(m["selected"], max(m["metrics"], key=lambda k: m["metrics"][k]["f1"]))
        for n in m["metrics"]:
            self.assertTrue(os.path.exists(f"outputs/figures/classification_report_{n}.txt"))
            self.assertTrue(os.path.exists(f"outputs/figures/confusion_matrix_{n}.png"))
        model, _ = rm.load_risk_model()
        test = pd.read_csv("outputs/test_split.csv", keep_default_na=False, na_values=[""])
        np.testing.assert_allclose(model.predict_proba(test[rm.FEATURES])[:, 1],
                                   pd.read_csv("outputs/test_predictions.csv").y_score, atol=1e-12)


class Module2(unittest.TestCase):
    def setUp(self): self.e = attention.SelfAttentionEngine()

    def test_fr_2_1_encode_shape(self): self.assertEqual(self.e.encode_sequence("ACGU").shape, (4, attention.EMBED_DIM))
    def test_fr_2_2_rejects_bad_char(self):
        with self.assertRaises(attention.InvalidSequenceError): self.e.encode_sequence("ACGX")
    def test_length_range_enforced_at_entry_point(self):
        for s in ("ACG", "A" * 51):
            with self.assertRaises(attention.InvalidSequenceError): self.e.analyze(s)
    def test_fr_2_3_2_4_shape_and_rowsums(self):
        for s in ("ACGUACGUACGGCUA", "AAAAA", "ACGU" * 12 + "AC"):
            w = self.e.analyze(s)["weights"]; self.assertEqual(w.shape, (len(s), len(s))); self.assertTrue(np.allclose(w.sum(1), 1.0))
    def test_multihead_concat(self):
        e = attention.SelfAttentionEngine(num_heads=3); ws, out = e.multi_head(e.encode_sequence("ACGUACGU"))
        self.assertEqual((len(ws), out.shape), (3, (8, 3 * attention.EMBED_DIM)))
    def test_fr_2_5_heatmap_exists(self): self.assertGreater(os.path.getsize("outputs/figures/attention_heatmap.png"), 5000)


class Module3(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.idx = GuidelineIndex.load(log_path=None)

    def test_fr_3_1_chunk_sizes_and_overlap(self):
        with open("data/mrna_safety_guidelines.txt") as f: ch = chunk_text(f.read())
        for c in ch: self.assertTrue(300 <= count_tokens(c) <= 500)
        T = re.compile(r"\w+|[^\w\s]")
        for a, b in zip(ch, ch[1:]):
            ta, tb = T.findall(a), T.findall(b); self.assertTrue(any(ta[-n:] == tb[:n] for n in range(30, 70)))
    def test_fr_3_2_embedding_count(self): self.assertEqual(self.idx.backend.count(), len(self.idx.backend.chunks))
    def test_fr_3_3_persistence_fresh_instance(self):
        q = "monitoring after administration"
        self.assertEqual(self.idx.query(q, 2)[0], GuidelineIndex.load(log_path=None).query(q, 2)[0])
    def test_fr_3_4_3_5_topk_and_latency(self):
        for q in ["storage temperature", "dose above 100", "age 65", "biomarker", "hospitalization escalation"]:
            ch, lat, sims = self.idx.query(q, k=3)
            self.assertEqual(len(ch), 3); self.assertEqual(sims, sorted(sims, reverse=True)); self.assertTrue(0 < lat < 5)


class Fixed(LLMClient):
    name = "fixed"
    def __init__(self, replies): self.replies, self.calls = list(replies), 0
    def generate(self, s, u, c=None): self.calls += 1; return self.replies.pop(0)


GOOD = json.dumps({"Eligible_For_Vaccine": True, "Recommended_Dose_mg": 0.05, "Reasoning_Steps": ["x"],
                   "FDA_Safety_Warnings_Cited": ["Doses above 100 micrograms are considered high-reactogenicity doses and require secondary clinician review before administration."],
                   "Disclaimer": DISCLAIMER})


class Module4(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.idx = GuidelineIndex.load(log_path=None); cls.model, cls.meta = rm.load_risk_model()
        cls.P = {"Age": 40, "Biomarker_Level": 3.0, "Pre_Existing_Conditions": 0, "Vaccine_Dose_mcg": 50.0, "Prior_Reaction_History": "None"}
        cls.chunks, _ = rg.retrieve_for_patient(cls.idx, cls.P)

    def test_fr_4_1_schema_strict(self):
        for bad in ({"Eligible_For_Vaccine": True},
                    {"Eligible_For_Vaccine": "yes", "Recommended_Dose_mg": 1, "Reasoning_Steps": [], "FDA_Safety_Warnings_Cited": []},
                    {"Eligible_For_Vaccine": True, "Recommended_Dose_mg": "x", "Reasoning_Steps": [], "FDA_Safety_Warnings_Cited": []}):
            with self.assertRaises(ValidationError): ClinicalSafetyReport.model_validate(bad)

    def test_fr_4_2_prompt_only_supplied_facts(self):
        s, u = rg.build_prompt("Low", 0.1, ["CHUNK-A", "CHUNK-B"], "summary-x")
        for t in ("CHUNK-A", "summary-x"): self.assertIn(t, u)
        for t in ("Never invent a clinical metric", "Never recommend a dose that contradicts", "student engineering project"): self.assertIn(t, s if t != "student engineering project" else s.lower())

    def test_fr_4_3_one_retry_then_success(self):
        c = Fixed(["not json", GOOD]); _, n = rg.call_with_one_retry(c, "s", "u", None); self.assertEqual((c.calls, n), (2, 2))
    def test_fr_4_3_one_retry_then_error(self):
        c = Fixed(["bad", "{}", GOOD])
        with self.assertRaises(rg.ReportGenerationError): rg.call_with_one_retry(c, "s", "u", None)
        self.assertEqual(c.calls, 2)
    def test_fr_4_3_no_retry_when_valid(self):
        c = Fixed([GOOD]); rg.call_with_one_retry(c, "s", "u", None); self.assertEqual(c.calls, 1)

    def test_fr_4_4_dose_above_bound_rejected(self):
        rep = ClinicalSafetyReport.model_validate_json(GOOD.replace("0.05", "0.12"))
        out, actions = rg.apply_guardrails(rep, {**self.P, "Vaccine_Dose_mcg": 120.0}, self.chunks, "Low", BIO_T)
        self.assertFalse(out.Eligible_For_Vaccine); self.assertEqual(out.Recommended_Dose_mg, 0.0); self.assertTrue(actions)
    def test_guardrail_drops_hallucinated_citation(self):
        rep = ClinicalSafetyReport.model_validate_json(GOOD.replace("Doses above", "Invented text. Doses above", 1))
        out, _ = rg.apply_guardrails(rep, self.P, self.chunks, "Low", BIO_T)
        self.assertFalse(out.Eligible_For_Vaccine); self.assertEqual(out.FDA_Safety_Warnings_Cited, [])
    def test_insufficient_context_defaults_to_not_eligible(self):
        out = json.loads(OfflineGroundedLLM().generate("", "", {"patient": self.P, "chunks": ["Unrelated storage text."], "risk_label": "Low",
                                                                "risk_probability": .1, "biomarker_threshold": BIO_T}))
        self.assertFalse(out["Eligible_For_Vaccine"])

    def test_fr_4_5_disclaimer_always_present(self):
        rep = ClinicalSafetyReport.model_validate_json(GOOD.replace(DISCLAIMER, "all good"))
        out, _ = rg.apply_guardrails(rep, self.P, self.chunks, "Low", BIO_T)
        self.assertIn("student engineering project", out.Disclaimer.lower())
        files = [f for f in os.listdir("outputs/reports") if f.endswith(".json")]
        self.assertGreaterEqual(len(files), 5)
        for f in files: self.assertTrue(jload(f"outputs/reports/{f}")["Disclaimer"].strip())
    def test_fr_4_6_json_md_pairs(self):
        js = {f[:-5] for f in os.listdir("outputs/reports") if f.endswith(".json")}
        md = {f[:-3] for f in os.listdir("outputs/reports") if f.endswith(".md")}
        self.assertTrue(js and js == md)
    def test_end_to_end_report_valid(self):
        d = tempfile.mkdtemp(); o = rg.generate_report(self.P, self.idx, self.model, self.meta, OfflineGroundedLLM(), "t", out_dir=d)
        self.assertTrue(o["report"].FDA_Safety_Warnings_Cited); self.assertTrue(os.path.exists(f"{d}/t.md")); shutil.rmtree(d)


class Module5(unittest.TestCase):
    def test_fr_5_dashboard_dpi_and_regenerates_from_outputs(self):
        from PIL import Image
        from src import dashboard
        with Image.open("outputs/figures/dashboard.png") as im: self.assertGreaterEqual(im.info["dpi"][0], 149.9)
        d = tempfile.mkdtemp(); dashboard.build_dashboard("outputs", f"{d}/d.png"); self.assertTrue(os.path.exists(f"{d}/d.png")); shutil.rmtree(d)


if __name__ == "__main__":
    unittest.main()
