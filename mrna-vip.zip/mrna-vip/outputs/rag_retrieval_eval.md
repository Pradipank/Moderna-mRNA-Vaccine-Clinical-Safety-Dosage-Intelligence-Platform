| Question | Correct chunk ranked #1? | Top sim. | Latency (ms) | Top result (start) |
|---|---|---|---|---|
| What are the storage requirements below -20C? | yes | 0.14 | 0.16 | Section 1: Storage and Handling Requirements  1.1 Ultra-Low Temperatur… |
| How long can a thawed vial stay refrigerated? | yes | 0.15 | 0.06 | Section 1: Storage and Handling Requirements  1.1 Ultra-Low Temperatur… |
| What dose needs secondary clinician review? | yes | 0.19 | 0.05 | and should be reported through the standard product-quality complaint … |
| How should patients aged 65 and older with several conditions be handled? | yes | 0.09 | 0.12 | and should be reported through the standard product-quality complaint … |
| How long must a patient be monitored after injection? | yes | 0.10 | 0.04 | 's discretion.  Section 3: Contraindications and Warnings  3.1 Absolut… |
| Which adverse events must be reported within 24 hours? | yes | 0.22 | 0.08 | 's discretion.  Section 3: Contraindications and Warnings  3.1 Absolut… |
| Is it safe to vaccinate someone with kidney disease? | n/a | 0.00 | 0.03 | Section 1: Storage and Handling Requirements  1.1 Ultra-Low Temperatur… |

Top-1 hit rate on in-scope questions: 6/6
Backend: local-tfidf; chunks: 3
