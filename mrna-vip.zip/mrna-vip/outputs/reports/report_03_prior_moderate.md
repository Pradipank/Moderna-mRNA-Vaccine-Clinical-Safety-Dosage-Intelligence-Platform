# Clinical Safety Report — report_03_prior_moderate

> **Student engineering project output — not real clinical guidance.**

**Patient:** 42-year-old, 1 pre-existing condition(s), biomarker 4.26 mg/L, prior reaction history: Moderate, candidate dose 51.9 mcg
**Risk model:** Low (p = 0.43)

## Decision
- **Eligible for vaccine:** NO
- **Recommended dose:** 0 mg (0 mcg)

## Reasoning
1. Risk model output: Low reaction risk (probability 0.43).
2. Prior moderate reaction history requires secondary review.
3. Checked with no trigger: max_dose_bound, age65_multi_condition, three_plus_conditions, high_dose_and_elevated_biomarker, elevated_biomarker_defer.
4. Allergy / anaphylaxis history is not part of the supplied patient record; contraindication screening must be completed by a clinician.

## Guideline excerpts cited
> Prior history of a moderate reaction to an mRNA-based product, even if the reaction has since resolved.
> Patients should be monitored for at least 15 minutes following administration, or 30 minutes for patients with a documented history of any allergic reaction.

## Provenance
- LLM provider: `offline-rule-based (not an LLM)` (attempts: 1)
- Guideline chunks retrieved: 3 via local-tfidf
- Guardrail actions: none

*Student engineering project output — not real clinical guidance.*
