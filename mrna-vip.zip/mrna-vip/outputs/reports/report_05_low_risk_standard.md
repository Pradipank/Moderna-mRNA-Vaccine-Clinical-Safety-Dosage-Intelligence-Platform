# Clinical Safety Report — report_05_low_risk_standard

> **Student engineering project output — not real clinical guidance.**

**Patient:** 52-year-old, 0 pre-existing condition(s), biomarker 2.00 mg/L, prior reaction history: None, candidate dose 90.8 mcg
**Risk model:** Low (p = 0.10)

## Decision
- **Eligible for vaccine:** YES
- **Recommended dose:** 0.0908 mg (90.8 mcg)

## Reasoning
1. Risk model output: Low reaction risk (probability 0.10).
2. Checked with no trigger: max_dose_bound, age65_multi_condition, three_plus_conditions, prior_moderate_reaction, high_dose_and_elevated_biomarker, elevated_biomarker_defer.
3. Allergy / anaphylaxis history is not part of the supplied patient record; contraindication screening must be completed by a clinician.
4. No guideline precaution was triggered and predicted risk is Low; candidate dose is within the stated threshold.

## Guideline excerpts cited
> Patients should be monitored for at least 15 minutes following administration, or 30 minutes for patients with a documented history of any allergic reaction.
> Doses above 100 micrograms are considered high-reactogenicity doses and require secondary clinician review before administration.

## Provenance
- LLM provider: `offline-rule-based (not an LLM)` (attempts: 1)
- Guideline chunks retrieved: 3 via local-tfidf
- Guardrail actions: none

*Student engineering project output — not real clinical guidance.*
