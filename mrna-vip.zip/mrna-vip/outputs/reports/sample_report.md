# Clinical Safety Report — sample_report

> **Student engineering project output — not real clinical guidance.**

**Patient:** 58-year-old, 2 pre-existing condition(s), biomarker 6.10 mg/L, prior reaction history: None, candidate dose 120 mcg
**Risk model:** High (p = 0.77)

## Decision
- **Eligible for vaccine:** NO
- **Recommended dose:** 0 mg (0 mcg)

## Reasoning
1. Risk model output: High reaction risk (probability 0.77).
2. Predicted risk is High, so the conservative default is NOT eligible pending clinician review.
3. Candidate dose 120 mcg exceeds the 100 mcg threshold stated in the guideline.
4. Checked with no trigger: age65_multi_condition, three_plus_conditions, prior_moderate_reaction, high_dose_and_elevated_biomarker, elevated_biomarker_defer.
5. Allergy / anaphylaxis history is not part of the supplied patient record; contraindication screening must be completed by a clinician.

## Guideline excerpts cited
> Doses above 100 micrograms are considered high-reactogenicity doses and require secondary clinician review before administration.
> Patients should be monitored for at least 15 minutes following administration, or 30 minutes for patients with a documented history of any allergic reaction.

## Provenance
- LLM provider: `offline-rule-based (not an LLM)` (attempts: 1)
- Guideline chunks retrieved: 3 via local-tfidf
- Guardrail actions: none

*Student engineering project output — not real clinical guidance.*
