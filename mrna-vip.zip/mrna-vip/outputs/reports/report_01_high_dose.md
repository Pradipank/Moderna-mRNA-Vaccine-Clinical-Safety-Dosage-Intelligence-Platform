# Clinical Safety Report — report_01_high_dose

> **Student engineering project output — not real clinical guidance.**

**Patient:** 67-year-old, 3 pre-existing condition(s), biomarker 7.22 mg/L, prior reaction history: Mild, candidate dose 120.4 mcg
**Risk model:** High (p = 0.96)

## Decision
- **Eligible for vaccine:** NO
- **Recommended dose:** 0 mg (0 mcg)

## Reasoning
1. Risk model output: High reaction risk (probability 0.96).
2. Predicted risk is High, so the conservative default is NOT eligible pending clinician review.
3. Candidate dose 120.4 mcg exceeds the 100 mcg threshold stated in the guideline.
4. Age 67 with 3 pre-existing conditions requires secondary clinician review.
5. 3 pre-existing conditions (>=3) requires secondary review.
6. Dose 120.4 mcg combined with an elevated biomarker (7.22 mg/L > 7.00, dataset-relative cut-off) requires secondary review.
7. Biomarker 7.22 mg/L is above the dataset-relative elevated cut-off (7.00); guideline: defer dosing or use lowest dose tier with enhanced monitoring.
8. Checked with no trigger: prior_moderate_reaction.
9. Allergy / anaphylaxis history is not part of the supplied patient record; contraindication screening must be completed by a clinician.

## Guideline excerpts cited
> Doses above 100 micrograms are considered high-reactogenicity doses and require secondary clinician review before administration.
> Ages 65 and older: standard adult dosing range applies; however, patients in this age band with two or more relevant pre-existing conditions should be flagged for secondary clinician review regardless of dose, due to elevated reactogenicity risk observed in this population.
> Three or more relevant pre-existing conditions at time of screening.
> Candidate dose exceeding 100 micrograms combined with an elevated biomarker level.
> Patients presenting with an inflammatory biomarker level meaningfully above the normal reference range at the time of screening should have dosing deferred until the biomarker returns to a normal range, or should receive the lowest clinically appropriate dose tier with enhanced post-administration monitoring, at the administering clinician's discretion.
> Patients should be monitored for at least 15 minutes following administration, or 30 minutes for patients with a documented history of any allergic reaction.

## Provenance
- LLM provider: `offline-rule-based (not an LLM)` (attempts: 1)
- Guideline chunks retrieved: 3 via local-tfidf
- Guardrail actions: none

*Student engineering project output — not real clinical guidance.*
