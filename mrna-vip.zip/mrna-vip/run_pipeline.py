"""Run Modules 1-5 end to end:  python run_pipeline.py [--provider offline|anthropic|openai]"""
import argparse
import os

import pandas as pd

from src import attention, dashboard, eda, rag_eval, risk_model
from src.llm_clients import get_client
from src.rag_index import GuidelineIndex
from src.report_generator import generate_report

FEATURES = risk_model.FEATURES


def pick_samples(test: pd.DataFrame) -> list[tuple[str, dict]]:
    """Five varied test-set patients so every guideline rule/guardrail is exercised."""
    picks = [
        ("high_dose", test[test.Vaccine_Dose_mcg > 100]),
        ("age65_multi_cond", test[(test.Age >= 65) & (test.Pre_Existing_Conditions >= 2)]),
        ("prior_moderate", test[test.Prior_Reaction_History == "Moderate"]),
        ("three_plus_cond", test[test.Pre_Existing_Conditions >= 3]),
        ("low_risk_standard", test[(test.Vaccine_Dose_mcg <= 100) & (test.Age < 65) & (test.Pre_Existing_Conditions <= 1)
                                   & (test.Prior_Reaction_History != "Moderate")]),
    ]
    return [(n, d.iloc[0][FEATURES].to_dict()) for n, d in picks if len(d)]


def main(provider=None):
    for f in ("outputs/latency_log.json", "outputs/rag_query_log.jsonl"):
        if os.path.exists(f):
            os.remove(f)
    risk_model.run(); eda.run(); attention.run()
    index = GuidelineIndex.build("data/mrna_safety_guidelines.txt")
    rag_eval.run()
    test = pd.read_csv("outputs/test_split.csv", keep_default_na=False, na_values=[""])
    model, meta = risk_model.load_risk_model()
    client = get_client(provider)
    print(f"\nLLM provider: {client.name}")
    for i, (name, patient) in enumerate(pick_samples(test), 1):
        out = generate_report(patient, index, model, meta, client, f"report_{i:02d}_{name}")
        r = out["report"]
        print(f"report_{i:02d}_{name}: eligible={r.Eligible_For_Vaccine} dose={r.Recommended_Dose_mg} "
              f"risk={out['prov']['risk_label']}({out['prov']['risk_probability']:.2f}) attempts={out['prov']['attempts']}")
    print("Dashboard:", dashboard.build_dashboard())


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--provider", default=None)
    main(ap.parse_args().provider)
