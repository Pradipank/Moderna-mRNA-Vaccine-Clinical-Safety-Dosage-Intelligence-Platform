"""Week-1 EDA figures: distributions, correlation heatmap, class balance."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

from src.data_pipeline import REACTION_ORDER, load_raw


def run(path="data/patient_records.csv", out="outputs/figures"):
    df = load_raw(path)
    fig, ax = plt.subplots(1, 3, figsize=(15, 4))
    for a, c in zip(ax, ["Age", "Biomarker_Level", "Vaccine_Dose_mcg"]):
        sns.histplot(data=df, x=c, hue="Reaction_Score", kde=True, ax=a, palette=["#0F6E6E", "#C0392B"])
        a.set_title(f"{c} by Reaction_Score")
    fig.tight_layout(); fig.savefig(f"{out}/eda_distributions.png", dpi=150); plt.close(fig)

    enc = df.copy()
    enc["Prior_Reaction_History"] = enc["Prior_Reaction_History"].map({k: i for i, k in enumerate(REACTION_ORDER)})
    fig, ax = plt.subplots(figsize=(7, 5.5))
    sns.heatmap(enc.drop(columns="Patient_ID").corr(), annot=True, fmt=".2f", cmap="vlag", center=0, ax=ax)
    ax.set_title("Correlation heatmap (history ordinal-encoded)")
    fig.tight_layout(); fig.savefig(f"{out}/eda_correlation.png", dpi=150); plt.close(fig)

    fig, ax = plt.subplots(1, 2, figsize=(10, 4))
    df["Reaction_Score"].value_counts().sort_index().plot.bar(ax=ax[0], color=["#0F6E6E", "#C0392B"])
    ax[0].set(title="Class balance (0=Low, 1=High)", xlabel="Reaction_Score", ylabel="Patients")
    pd.crosstab(df["Prior_Reaction_History"].fillna("MISSING"), df["Reaction_Score"], normalize="index").plot.bar(
        ax=ax[1], stacked=True, color=["#0F6E6E", "#C0392B"])
    ax[1].set(title="High-risk share by prior reaction history", ylabel="Share")
    fig.tight_layout(); fig.savefig(f"{out}/eda_class_balance.png", dpi=150); plt.close(fig)
    print(df.groupby("Reaction_Score")[["Age", "Biomarker_Level", "Vaccine_Dose_mcg", "Pre_Existing_Conditions"]].mean().round(2).to_string())


if __name__ == "__main__":
    run()
