"""Output schema for the clinical safety report (FR-4.1).

Uses Pydantic v2 when installed. If Pydantic is unavailable (offline sandbox) a small strict
fallback with the same field names, `model_validate`, `model_dump` and a `ValidationError` is used.
"""
from __future__ import annotations

import json
from typing import List

DISCLAIMER = "Student engineering project output — not real clinical guidance."

try:                                                     # ---- real Pydantic
    from pydantic import BaseModel, Field, StrictBool, ValidationError

    class ClinicalSafetyReport(BaseModel):
        Eligible_For_Vaccine: StrictBool = Field(..., description="Whether the patient is eligible given risk and guidelines")
        Recommended_Dose_mg: float = Field(..., description="Recommended dose in mg, must respect retrieved guideline bounds")
        Reasoning_Steps: List[str] = Field(..., description="Ordered, human-readable reasoning steps behind the decision")
        FDA_Safety_Warnings_Cited: List[str] = Field(..., description="Exact guideline snippets the recommendation relies on")
        Disclaimer: str = Field(default=DISCLAIMER, description="Must always be present in the final report")

    BACKEND = "pydantic"

except ImportError:                                      # ---- strict fallback
    BACKEND = "fallback"

    class ValidationError(ValueError):
        pass

    class ClinicalSafetyReport:
        _FIELDS = ("Eligible_For_Vaccine", "Recommended_Dose_mg", "Reasoning_Steps",
                   "FDA_Safety_Warnings_Cited", "Disclaimer")

        def __init__(self, **kw):
            errs = []
            extra = set(kw) - set(self._FIELDS)
            if extra:
                errs.append(f"unexpected field(s): {sorted(extra)}")
            kw.setdefault("Disclaimer", DISCLAIMER)
            errs += [f"{f}: field required" for f in self._FIELDS if f not in kw]
            b, d = kw.get("Eligible_For_Vaccine"), kw.get("Recommended_Dose_mg")
            if "Eligible_For_Vaccine" in kw and not isinstance(b, bool):
                errs.append("Eligible_For_Vaccine: must be a bool")
            if "Recommended_Dose_mg" in kw and (isinstance(d, bool) or not isinstance(d, (int, float))):
                errs.append("Recommended_Dose_mg: must be a number")
            for f in ("Reasoning_Steps", "FDA_Safety_Warnings_Cited"):
                v = kw.get(f)
                if f in kw and not (isinstance(v, list) and all(isinstance(x, str) for x in v)):
                    errs.append(f"{f}: must be a list of strings")
            if "Disclaimer" in kw and not isinstance(kw["Disclaimer"], str):
                errs.append("Disclaimer: must be a string")
            if errs:
                raise ValidationError("; ".join(errs))
            for f in self._FIELDS:
                setattr(self, f, float(kw[f]) if f == "Recommended_Dose_mg" else kw[f])

        @classmethod
        def model_validate(cls, data):
            if not isinstance(data, dict):
                raise ValidationError("report must be a JSON object")
            return cls(**data)

        @classmethod
        def model_validate_json(cls, text):
            try:
                return cls.model_validate(json.loads(text))
            except json.JSONDecodeError as e:
                raise ValidationError(f"invalid JSON: {e}") from e

        def model_dump(self):
            return {f: getattr(self, f) for f in self._FIELDS}

        def model_dump_json(self, indent=None):
            return json.dumps(self.model_dump(), indent=indent, ensure_ascii=False)
