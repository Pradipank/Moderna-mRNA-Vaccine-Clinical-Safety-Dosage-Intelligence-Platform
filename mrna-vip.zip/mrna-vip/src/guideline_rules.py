"""Deterministic guideline checks used by (a) the offline generator and (b) the post-LLM guardrail.

Every rule is *anchored* to a phrase that must appear in the RETRIEVED text. If the anchor was not
retrieved the rule cannot fire and the report becomes "insufficient information" (conservative).
Nothing here encodes a clinical fact that is not in the guideline document.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

DOSE_BOUND_RE = re.compile(r"[Dd]oses above (\d+(?:\.\d+)?) micrograms")


def split_sentences(text: str) -> list[str]:
    """Sentence-/bullet-level snippets that are exact substrings of `text`."""
    out = []
    for block in re.split(r"\n+", text):
        block = block.strip().lstrip("- ").strip()
        out += [s.strip() for s in re.split(r"(?<=[.!?])\s+", block) if s.strip()]
    return out


def find_snippet(chunks: list[str], anchor: str) -> str | None:
    for ch in chunks:
        for s in split_sentences(ch):
            if anchor.lower() in s.lower() and s in ch:
                return s
    return None


def max_dose_bound_mcg(chunks: list[str]) -> float | None:
    for ch in chunks:
        m = DOSE_BOUND_RE.search(ch)
        if m:
            return float(m.group(1))
    return None


@dataclass
class Finding:
    rule: str
    triggered: bool
    snippet: str | None
    message: str


def evaluate(patient: dict, chunks: list[str], biomarker_elevated_threshold: float) -> dict:
    """Apply every guideline rule whose anchor text was retrieved.

    The guideline gives NO numeric cut-off for an 'elevated' biomarker, so a dataset-relative value
    (training-set 75th percentile) is supplied and always labelled as such.
    """
    age, cond, dose = patient["Age"], patient["Pre_Existing_Conditions"], patient["Vaccine_Dose_mcg"]
    bio, prior = patient["Biomarker_Level"], patient["Prior_Reaction_History"]
    bio_high = bio > biomarker_elevated_threshold
    bound = max_dose_bound_mcg(chunks)
    F: list[Finding] = []
    missing: list[str] = []

    def rule(name, anchor, cond_true, msg_true):
        snip = find_snippet(chunks, anchor)
        if snip is None:
            missing.append(name)
            return
        F.append(Finding(name, bool(cond_true), snip, msg_true if cond_true else ""))

    snip = find_snippet(chunks, "Doses above")
    if bound is None or snip is None:
        missing.append("max_dose_bound")
    else:
        F.append(Finding("max_dose_bound", dose > bound, snip,
                         f"Candidate dose {dose:g} mcg exceeds the {bound:g} mcg threshold stated in the guideline."))
    rule("age65_multi_condition", "two or more relevant pre-existing conditions", age >= 65 and cond >= 2,
         f"Age {age} with {cond} pre-existing conditions requires secondary clinician review.")
    rule("three_plus_conditions", "Three or more relevant pre-existing conditions", cond >= 3,
         f"{cond} pre-existing conditions (>=3) requires secondary review.")
    rule("prior_moderate_reaction", "moderate reaction to an mRNA-based product", prior == "Moderate",
         "Prior moderate reaction history requires secondary review.")
    rule("high_dose_and_elevated_biomarker", "exceeding 100 micrograms combined with an elevated biomarker",
         bound is not None and dose > bound and bio_high,
         f"Dose {dose:g} mcg combined with an elevated biomarker ({bio:g} mg/L > {biomarker_elevated_threshold:.2f}, "
         f"dataset-relative cut-off) requires secondary review.")
    rule("elevated_biomarker_defer", "dosing deferred until the biomarker returns", bio_high,
         f"Biomarker {bio:g} mg/L is above the dataset-relative elevated cut-off ({biomarker_elevated_threshold:.2f}); "
         f"guideline: defer dosing or use lowest dose tier with enhanced monitoring.")
    return {"findings": F, "missing": missing, "bound_mcg": bound, "biomarker_elevated": bio_high,
            "monitoring_snippet": find_snippet(chunks, "monitored for at least 15 minutes")}
