"""LLM providers behind one tiny interface: generate(system, user, context) -> raw text.

* AnthropicClient / OpenAIClient: hosted LLMs (stdlib HTTP only; need an API key in .env). UNTESTED offline.
* OfflineGroundedLLM: deterministic stand-in that applies the guideline rules to the *retrieved chunks*.
  It is NOT a language model; its name is stored in every report's provenance.
"""
from __future__ import annotations

import json
import os
import urllib.request

from src import guideline_rules as rules
from src.schemas import DISCLAIMER


class LLMClient:
    name = "base"

    def generate(self, system: str, user: str, context: dict | None = None) -> str:
        raise NotImplementedError


def _post(url: str, headers: dict, body: dict, timeout: int = 60) -> dict:
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers={"Content-Type": "application/json", **headers})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read())


class AnthropicClient(LLMClient):
    def __init__(self, model: str | None = None):
        self.model = model or os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5-5")
        self.key = os.environ["ANTHROPIC_API_KEY"]
        self.name = f"anthropic:{self.model}"

    def generate(self, system, user, context=None):
        r = _post("https://api.anthropic.com/v1/messages", {"x-api-key": self.key, "anthropic-version": "2023-06-01"},
                  {"model": self.model, "max_tokens": 1500, "temperature": 0, "system": system,
                   "messages": [{"role": "user", "content": user}]})
        return "".join(b.get("text", "") for b in r["content"])


class OpenAIClient(LLMClient):
    def __init__(self, model: str | None = None):
        self.model = model or os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        self.key = os.environ["OPENAI_API_KEY"]
        self.name = f"openai:{self.model}"

    def generate(self, system, user, context=None):
        r = _post("https://api.openai.com/v1/chat/completions", {"Authorization": f"Bearer {self.key}"},
                  {"model": self.model, "temperature": 0, "response_format": {"type": "json_object"},
                   "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]})
        return r["choices"][0]["message"]["content"]


class OfflineGroundedLLM(LLMClient):
    name = "offline-rule-based (not an LLM)"

    def generate(self, system, user, context=None):
        c = context
        p, chunks = c["patient"], c["chunks"]
        ev = rules.evaluate(p, chunks, c["biomarker_threshold"])
        triggered = [f for f in ev["findings"] if f.triggered]
        passed = [f for f in ev["findings"] if not f.triggered]
        high, insufficient = c["risk_label"] == "High", bool(ev["missing"])
        eligible = not (high or triggered or insufficient)

        steps = [f"Risk model output: {c['risk_label']} reaction risk (probability {c['risk_probability']:.2f})."]
        if high:
            steps.append("Predicted risk is High, so the conservative default is NOT eligible pending clinician review.")
        steps += [f.message for f in triggered]
        if passed:
            steps.append("Checked with no trigger: " + ", ".join(f.rule for f in passed) + ".")
        if insufficient:
            steps.append("Retrieved guideline text did not cover: " + ", ".join(ev["missing"]) +
                         ". Insufficient information, so defaulting to NOT eligible rather than guessing.")
        steps.append("Allergy / anaphylaxis history is not part of the supplied patient record; contraindication "
                     "screening must be completed by a clinician.")
        if eligible:
            steps.append("No guideline precaution was triggered and predicted risk is Low; candidate dose is within the stated threshold.")
        cites = [f.snippet for f in triggered] + ([ev["monitoring_snippet"]] if ev["monitoring_snippet"] else [])
        if eligible:
            cites += [f.snippet for f in passed if f.rule == "max_dose_bound"]
        cites = list(dict.fromkeys(s for s in cites if s))
        return json.dumps({"Eligible_For_Vaccine": eligible,
                           "Recommended_Dose_mg": round(p["Vaccine_Dose_mcg"] / 1000, 4) if eligible else 0.0,
                           "Reasoning_Steps": steps, "FDA_Safety_Warnings_Cited": cites, "Disclaimer": DISCLAIMER})


def get_client(provider: str | None = None) -> LLMClient:
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass
    provider = (provider or os.getenv("LLM_PROVIDER", "auto")).lower()
    if provider == "auto":
        provider = "anthropic" if os.getenv("ANTHROPIC_API_KEY") else "openai" if os.getenv("OPENAI_API_KEY") else "offline"
    return {"anthropic": AnthropicClient, "openai": OpenAIClient, "offline": OfflineGroundedLLM}[provider]()
