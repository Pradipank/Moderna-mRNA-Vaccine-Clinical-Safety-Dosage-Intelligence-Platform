"""Module 5 - 3-panel dashboard built from the modules' SAVED outputs (FR-5.1/5.2/5.3)."""
from __future__ import annotations

import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import auc, roc_curve


def _json(path):
    with open(path) as f:
        return json.load(f)


def build_dashboard(out_dir: str = "outputs", save_path: str | None = None):
    save_path = save_path or f"{out_dir}/figures/dashboard.png"
    pred = pd.read_csv(f"{out_dir}/test_predictions.csv")
    att = np.load(f"{out_dir}/attention_result.npz")
    weights, seq = att["weights"], str(att["sequence"])
    metrics, lat = _json(f"{out_dir}/model_metrics.json"), _json(f"{out_dir}/latency_log.json")
    rag, llm = float(np.mean([e["rag_mean_s"] for e in lat])), float(np.mean([e["llm_s"] for e in lat]))

    fig, ax = plt.subplots(1, 3, figsize=(18, 5.4))
    fpr, tpr, _ = roc_curve(pred.y_true, pred.y_score)
    ax[0].plot(fpr, tpr, lw=2, color="#0F6E6E", label=f"{metrics['selected']}  AUC = {auc(fpr, tpr):.2f}")
    ax[0].plot([0, 1], [0, 1], "--", color="gray")
    ax[0].set(title="Panel A - Risk Classifier ROC Curve (held-out test set)", xlabel="False Positive Rate", ylabel="True Positive Rate")
    ax[0].legend(loc="lower right")

    im = ax[1].imshow(weights, cmap="viridis")
    ax[1].set_xticks(range(len(seq)), list(seq), fontsize=7); ax[1].set_yticks(range(len(seq)), list(seq), fontsize=7)
    ax[1].set(title="Panel B - mRNA Self-Attention Weights", xlabel="Attending TO", ylabel="Attending FROM")
    fig.colorbar(im, ax=ax[1], fraction=0.046)

    bars = ax[2].bar(["RAG retrieval\n(per query)", "Report generation\n(per report)"], [rag, llm], color=["#0F6E6E", "#1F3A5F"])
    ax[2].set_yscale("log")
    for b, v in zip(bars, [rag, llm]):
        ax[2].text(b.get_x() + b.get_width() / 2, v, f"{v:.4f}s", ha="center", va="bottom")
    ax[2].set(title="Panel C - Pipeline Stage Latency", ylabel="Seconds (log scale)")
    ax[2].text(0.5, -0.2, f"generation provider: {lat[-1]['provider']}", transform=ax[2].transAxes, ha="center", fontsize=8, color="gray")
    fig.suptitle("Moderna mRNA-VIP — Clinical Safety & Dosage Intelligence (student project, not clinical guidance)", fontsize=11)
    fig.tight_layout(); fig.savefig(save_path, dpi=150); plt.close(fig)
    return save_path


if __name__ == "__main__":
    print(build_dashboard())
