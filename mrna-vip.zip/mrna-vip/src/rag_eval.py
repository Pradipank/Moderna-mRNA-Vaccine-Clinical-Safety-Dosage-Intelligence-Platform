"""Week-3 retrieval check: questions, expected phrase, latency -> outputs/rag_retrieval_eval.md."""
from src.rag_index import GuidelineIndex

CASES = [
    ("What are the storage requirements below -20C?", "ultra-low temperature"),
    ("How long can a thawed vial stay refrigerated?", "30 days"),
    ("What dose needs secondary clinician review?", "Doses above 100 micrograms"),
    ("How should patients aged 65 and older with several conditions be handled?", "two or more relevant pre-existing conditions"),
    ("How long must a patient be monitored after injection?", "15 minutes"),
    ("Which adverse events must be reported within 24 hours?", "within 24 hours"),
    ("Is it safe to vaccinate someone with kidney disease?", "(not covered by the guideline)"),   # out-of-scope probe
]


def run(out="outputs/rag_retrieval_eval.md"):
    idx = GuidelineIndex.load(log_path=None)
    rows, hits = [], 0
    for q, expect in CASES:
        chunks, lat, sims = idx.query(q, k=3)
        ok = expect in chunks[0] if not expect.startswith("(") else None
        hits += bool(ok)
        rows.append(f"| {q} | {'n/a' if ok is None else ('yes' if ok else '**NO**')} | {sims[0]:.2f} | {lat * 1000:.2f} | {chunks[0].replace(chr(10), ' ')[:70]}… |")
    md = ["| Question | Correct chunk ranked #1? | Top sim. | Latency (ms) | Top result (start) |", "|---|---|---|---|---|"] + rows
    md += ["", f"Top-1 hit rate on in-scope questions: {hits}/{len(CASES) - 1}", f"Backend: {idx.backend.name}; chunks: {idx.backend.count()}"]
    open(out, "w").write("\n".join(md) + "\n")
    print("\n".join(md))


if __name__ == "__main__":
    run()
