"""Module 4 - grounded, schema-validated clinical safety report generation."""
from __future__ import annotations

import json
import os
import re
import time

from src import guideline_rules as rules
from src.llm_clients import LLMClient, get_client
from src.rag_index import GuidelineIndex
from src.risk_model import load_risk_model, score_patient
from src.schemas import DISCLAIMER, ClinicalSafetyReport, ValidationError

REPORT_DIR = "outputs/reports"
LATENCY_LOG = "outputs/latency_log.json"

SYSTEM_PROMPT = """You are a clinical safety reporting assistant for a STUDENT ENGINEERING PROJECT.
You must ONLY use the risk score, patient summary and guideline excerpts provided below.
Rules:
1) Never recommend a dose that contradicts the retrieved guideline text.
2) Never invent a clinical metric, statistic, or guideline that was not present in the retrieved chunks.
3) If the retrieved chunks do not contain enough information to answer confidently, set Eligible_For_Vaccine to false
   (the conservative default), set Recommended_Dose_mg to 0, and explain why in Reasoning_Steps rather than guessing.
4) Every report must include the Disclaimer field stating this is a student engineering project and not real clinical guidance.
FDA_Safety_Warnings_Cited must contain exact, verbatim sentences copied from the guideline excerpts.
Recommended_Dose_mg is in MILLIGRAMS (1 mg = 1000 mcg); the patient's dose is given in micrograms.
Respond with ONE JSON object only (no markdown fences) with exactly these keys:
Eligible_For_Vaccine (bool), Recommended_Dose_mg (number), Reasoning_Steps (list of strings),
FDA_Safety_Warnings_Cited (list of strings), Disclaimer (string)."""


class ReportGenerationError(RuntimeError):
    """Raised when the LLM output is still invalid after the single permitted retry (FR-4.3)."""


def profile_queries(p: dict) -> list[tuple[str, str]]:
    return [
        ("dose", f"Is a candidate dose of {p['Vaccine_Dose_mcg']:g} micrograms above the dose that needs secondary clinician review?"),
        ("age", f"Dosing guidance and review rules for a patient aged {p['Age']}"),
        ("conditions", f"Precautions requiring secondary review for {p['Pre_Existing_Conditions']} pre-existing conditions"),
        ("biomarker", "Dose adjustment for elevated inflammatory biomarker level"),
        ("history", f"Precautions for prior {p['Prior_Reaction_History']} reaction history and post-administration monitoring"),
    ]


def retrieve_for_patient(index: GuidelineIndex, patient: dict, k: int = 2):
    chunks, lat = [], []
    for purpose, q in profile_queries(patient):
        got, latency, _ = index.query(q, k=k, purpose=purpose)
        lat.append(latency)
        chunks += [c for c in got if c not in chunks]
    return chunks, lat


def patient_summary(p: dict) -> str:
    return (f"{p['Age']}-year-old, {p['Pre_Existing_Conditions']} pre-existing condition(s), "
            f"biomarker {p['Biomarker_Level']:.2f} mg/L, prior reaction history: {p['Prior_Reaction_History']}, "
            f"candidate dose {p['Vaccine_Dose_mcg']:g} mcg")


def build_prompt(risk_label: str, risk_probability: float, chunks: list[str], summary: str) -> tuple[str, str]:
    """FR-4.2: the ONLY factual grounding is the risk output + retrieved chunks (+ the patient's own data)."""
    user = (f"Patient summary: {summary}\nPredicted risk label: {risk_label} (probability {risk_probability:.2f})\n"
            "Relevant guideline excerpts:\n" + "\n---\n".join(chunks) +
            "\n\nGenerate the structured clinical safety report now as a single JSON object.")
    return SYSTEM_PROMPT, user


def parse_report(raw: str) -> ClinicalSafetyReport:
    text = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.M).strip()
    m = re.search(r"\{.*\}", text, re.S)
    return ClinicalSafetyReport.model_validate_json(m.group(0) if m else text)


def call_with_one_retry(client: LLMClient, system: str, user: str, context: dict | None):
    """Validate the response; on failure retry EXACTLY once with the error appended, then raise (FR-4.3)."""
    raw = client.generate(system, user, context)
    try:
        return parse_report(raw), 1
    except (ValidationError, ValueError) as first:
        retry_user = (user + f"\n\nYour previous reply was invalid: {first}\n"
                      "Reply again with ONE valid JSON object matching the schema exactly.")
        try:
            return parse_report(client.generate(system, retry_user, context)), 2
        except (ValidationError, ValueError) as second:
            raise ReportGenerationError(f"LLM output invalid after 1 retry: {second}") from second


def apply_guardrails(report: ClinicalSafetyReport, patient: dict, chunks: list[str],
                     risk_label: str, bio_threshold: float) -> tuple[ClinicalSafetyReport, list[str]]:
    """Deterministic post-checks that hold regardless of what the LLM said (FR-4.4 / FR-4.5)."""
    actions: list[str] = []
    steps = list(report.Reasoning_Steps)
    eligible, dose_mg = report.Eligible_For_Vaccine, report.Recommended_Dose_mg
    ev = rules.evaluate(patient, chunks, bio_threshold)

    bound = ev["bound_mcg"]
    if bound is not None and dose_mg * 1000 > bound + 1e-9:
        actions.append(f"dose {dose_mg * 1000:g} mcg exceeded guideline bound {bound:g} mcg -> rejected")
        steps.append(f"[Guardrail] Recommended dose {dose_mg * 1000:g} mcg exceeds the {bound:g} mcg bound in the retrieved guideline; rejected.")
        eligible, dose_mg = False, 0.0
    if bound is not None and patient["Vaccine_Dose_mcg"] > bound and eligible:
        actions.append("candidate dose above guideline bound -> not eligible")
        steps.append(f"[Guardrail] Candidate dose {patient['Vaccine_Dose_mcg']:g} mcg is above the {bound:g} mcg bound; not eligible.")
        eligible, dose_mg = False, 0.0
    triggered = any(f.triggered for f in ev["findings"])
    if eligible and (risk_label == "High" or triggered or ev["missing"]):
        why = ("High predicted risk" if risk_label == "High" else "a triggered guideline precaution" if triggered
               else "guideline text needed for a safe decision was not retrieved")
        actions.append(f"forced not eligible: {why}")
        steps.append(f"[Guardrail] Overrode eligibility to false because of {why}.")
        eligible, dose_mg = False, 0.0

    verbatim = [s for s in report.FDA_Safety_Warnings_Cited if any(s in ch for ch in chunks)]
    if len(verbatim) != len(report.FDA_Safety_Warnings_Cited):
        actions.append(f"dropped {len(report.FDA_Safety_Warnings_Cited) - len(verbatim)} citation(s) not found verbatim in retrieved text")
        steps.append("[Guardrail] Removed citation(s) that are not verbatim guideline text.")
    if not verbatim:
        actions.append("no verifiable citation -> not eligible")
        steps.append("[Guardrail] No verifiable guideline citation; defaulting to not eligible.")
        eligible, dose_mg = False, 0.0

    disclaimer = report.Disclaimer
    if "student engineering project" not in disclaimer.lower():
        actions.append("disclaimer restored")
        disclaimer = DISCLAIMER
    return ClinicalSafetyReport(Eligible_For_Vaccine=eligible, Recommended_Dose_mg=float(dose_mg),
                                Reasoning_Steps=steps, FDA_Safety_Warnings_Cited=verbatim, Disclaimer=disclaimer), actions


def to_markdown(report: ClinicalSafetyReport, prov: dict) -> str:
    r = report.model_dump()
    md = [f"# Clinical Safety Report — {prov['report_id']}", "", f"> **{r['Disclaimer']}**", "",
          f"**Patient:** {prov['patient_summary']}", f"**Risk model:** {prov['risk_label']} (p = {prov['risk_probability']:.2f})", "",
          "## Decision", f"- **Eligible for vaccine:** {'YES' if r['Eligible_For_Vaccine'] else 'NO'}",
          f"- **Recommended dose:** {r['Recommended_Dose_mg']:g} mg ({r['Recommended_Dose_mg'] * 1000:g} mcg)", "", "## Reasoning"] + \
         [f"{i}. {s}" for i, s in enumerate(r["Reasoning_Steps"], 1)] + ["", "## Guideline excerpts cited"] + \
         [f"> {s}" for s in r["FDA_Safety_Warnings_Cited"]] + \
         ["", "## Provenance", f"- LLM provider: `{prov['provider']}` (attempts: {prov['attempts']})",
          f"- Guideline chunks retrieved: {prov['n_chunks']} via {prov['retrieval_backend']}",
          f"- Guardrail actions: {prov['guardrail_actions'] or 'none'}", "", f"*{r['Disclaimer']}*", ""]
    return "\n".join(md)


def _append_latency(entry: dict, path: str = LATENCY_LOG):
    log = []
    if os.path.exists(path):
        with open(path) as f:
            log = json.load(f)
    log.append(entry)
    with open(path, "w") as f:
        json.dump(log, f, indent=2)


def generate_report(patient: dict, index: GuidelineIndex, model, meta: dict, client: LLMClient,
                    report_id: str, out_dir: str = REPORT_DIR) -> dict:
    risk_label, prob = score_patient(patient, model, meta)
    chunks, rag_lat = retrieve_for_patient(index, patient)
    summary = patient_summary(patient)
    system, user = build_prompt(risk_label, prob, chunks, summary)
    ctx = {"patient": patient, "chunks": chunks, "risk_label": risk_label, "risk_probability": prob,
           "biomarker_threshold": meta["biomarker_p75_train"]}
    t0 = time.perf_counter()
    report, attempts = call_with_one_retry(client, system, user, ctx)
    llm_latency = time.perf_counter() - t0
    report, actions = apply_guardrails(report, patient, chunks, risk_label, meta["biomarker_p75_train"])
    prov = {"report_id": report_id, "patient_summary": summary, "risk_label": risk_label, "risk_probability": prob,
            "provider": client.name, "attempts": attempts, "n_chunks": len(chunks),
            "retrieval_backend": index.backend.name, "guardrail_actions": actions}
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, f"{report_id}.json"), "w") as f:
        json.dump({**report.model_dump(), "_provenance": prov}, f, indent=2, ensure_ascii=False)
    with open(os.path.join(out_dir, f"{report_id}.md"), "w") as f:
        f.write(to_markdown(report, prov))
    _append_latency({"report_id": report_id, "rag_queries": len(rag_lat), "rag_mean_s": sum(rag_lat) / len(rag_lat),
                     "rag_total_s": sum(rag_lat), "llm_s": llm_latency, "provider": client.name})
    return {"report": report, "prov": prov, "prompt": (system, user), "chunks": chunks}


if __name__ == "__main__":
    idx = GuidelineIndex.load()
    model, meta = load_risk_model()
    sample = {"Age": 58, "Biomarker_Level": 6.1, "Pre_Existing_Conditions": 2,
              "Vaccine_Dose_mcg": 120.0, "Prior_Reaction_History": "None"}
    print(generate_report(sample, idx, model, meta, get_client(), "sample_report")["report"].model_dump_json(indent=2))
