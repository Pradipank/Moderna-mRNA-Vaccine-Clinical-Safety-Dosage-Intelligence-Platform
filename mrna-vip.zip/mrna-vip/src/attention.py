"""Module 2 - scaled dot-product self-attention over an mRNA sequence, from scratch (NumPy).

Attention(Q, K, V) = softmax(Q K^T / sqrt(d_k)) V
"""
from __future__ import annotations

import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

VOCAB = ["A", "C", "G", "U"]
EMBED_DIM = 8
MIN_LEN, MAX_LEN = 5, 50


class InvalidSequenceError(ValueError):
    """Raised for characters outside {A, C, G, U} or an out-of-range length (FR-2.2)."""


def validate_sequence(sequence: str, enforce_length: bool = True) -> str:
    seq = sequence.strip()
    bad = sorted({c for c in seq if c not in VOCAB})
    if bad or not seq:
        raise InvalidSequenceError(f"Invalid nucleotide(s) {bad or 'empty sequence'}; allowed: A, C, G, U")
    if enforce_length and not (MIN_LEN <= len(seq) <= MAX_LEN):
        raise InvalidSequenceError(f"Sequence length {len(seq)} outside {MIN_LEN}-{MAX_LEN}")
    return seq


class SelfAttentionEngine:
    """Holds the toy embedding table and Q/K/V weights so results are reproducible."""

    def __init__(self, embed_dim: int = EMBED_DIM, d_k: int | None = None, num_heads: int = 1,
                 seed: int = 42, weight_scale: float = 0.5, positional_encoding: bool = True):
        # weight_scale: the PRD template uses 0.1, which makes every logit tiny and the softmax
        # almost uniform (all weights ~1/n). 0.5 gives visibly structured attention.
        self.positional_encoding = positional_encoding
        rng = np.random.default_rng(seed)
        self.embed_dim, self.d_k, self.num_heads = embed_dim, d_k or embed_dim, num_heads
        self.embedding_table = {b: rng.standard_normal(embed_dim) for b in VOCAB}
        self.heads = [tuple(rng.standard_normal((embed_dim, self.d_k)) * weight_scale for _ in range(3))
                      for _ in range(num_heads)]

    def encode_sequence(self, sequence: str) -> np.ndarray:
        """'ACGU' -> (4, embed_dim). Characters always validated (FR-2.1/2.2); the 5-50 length rule
        is applied by `analyze` (pipeline entry point) so encode_sequence('ACGU') still works."""
        seq = validate_sequence(sequence, enforce_length=False)
        X = np.stack([self.embedding_table[b] for b in seq])
        return X + self._positional(len(seq)) if self.positional_encoding else X

    def _positional(self, n: int) -> np.ndarray:
        """Sinusoidal positional encoding so identical bases at different positions differ."""
        pos, i = np.arange(n)[:, None], np.arange(self.embed_dim)[None, :]
        angle = pos / np.power(10000, (2 * (i // 2)) / self.embed_dim)
        return np.where(i % 2 == 0, np.sin(angle), np.cos(angle))

    @staticmethod
    def softmax(x: np.ndarray) -> np.ndarray:
        x = x - np.max(x, axis=-1, keepdims=True)
        e = np.exp(x)
        return e / e.sum(axis=-1, keepdims=True)

    def self_attention(self, X: np.ndarray, head: int = 0):
        """Return (attention_weights (n, n), output (n, d_k)) for one head."""
        W_q, W_k, W_v = self.heads[head]
        Q, K, V = X @ W_q, X @ W_k, X @ W_v
        weights = self.softmax((Q @ K.T) / np.sqrt(self.d_k))
        return weights, weights @ V

    def multi_head(self, X: np.ndarray):
        """Bonus: run every head independently and concatenate outputs."""
        res = [self.self_attention(X, h) for h in range(self.num_heads)]
        return [w for w, _ in res], np.concatenate([o for _, o in res], axis=-1)

    def analyze(self, sequence: str) -> dict:
        seq = validate_sequence(sequence)
        X = self.encode_sequence(seq)
        weights, output = self.self_attention(X)
        assert np.allclose(weights.sum(axis=1), 1.0), "softmax rows must sum to 1"   # FR-2.4
        return {"sequence": seq, "X": X, "weights": weights, "output": output}


def plot_attention(weights: np.ndarray, sequence: str, save_path: str):
    os.makedirs(os.path.dirname(save_path) or ".", exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 6.5))
    im = ax.imshow(weights, cmap="viridis")
    labels = [f"{i + 1}:{b}" for i, b in enumerate(sequence)]
    ax.set_xticks(range(len(sequence)), labels, rotation=90, fontsize=8)
    ax.set_yticks(range(len(sequence)), labels, fontsize=8)
    ax.set_xlabel("Attending TO position"); ax.set_ylabel("Attending FROM position")
    ax.set_title("mRNA Sequence Self-Attention Weights")
    fig.colorbar(im, label="Attention weight")
    fig.tight_layout(); fig.savefig(save_path, dpi=150); plt.close(fig)


def run(sequence: str = "ACGUACGUACGGCUA", out_dir: str = "outputs"):
    res = SelfAttentionEngine().analyze(sequence)
    plot_attention(res["weights"], sequence, f"{out_dir}/figures/attention_heatmap.png")
    np.savez(f"{out_dir}/attention_result.npz", weights=res["weights"], sequence=sequence)
    w = res["weights"]
    print(f"weights {w.shape}, row sums ok, max={w.max():.3f} min={w.min():.3f} (uniform={1/len(sequence):.3f})")
    return res


if __name__ == "__main__":
    run()
