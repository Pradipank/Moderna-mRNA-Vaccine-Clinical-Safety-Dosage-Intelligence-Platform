"""Module 1b - Logistic Regression vs Random Forest risk classifier."""
from __future__ import annotations

import json
import os

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, f1_score, roc_auc_score
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OrdinalEncoder, StandardScaler

from src.data_pipeline import (CATEGORICAL_COL, COUNT_COL, NUMERIC_COLS, REACTION_ORDER,
                               TARGET_COL, impute, load_raw)

SEED = 42
FEATURES = NUMERIC_COLS + [CATEGORICAL_COL, COUNT_COL]
OUT = "outputs"


def split(df: pd.DataFrame, seed: int = SEED):
    """80/20 split stratified on the target with a fixed seed (FR-1.4)."""
    return train_test_split(df, test_size=0.2, random_state=seed, stratify=df[TARGET_COL])


def make_preprocessor() -> ColumnTransformer:
    # Scaler is fit on the TRAIN split only (FR-1.3) -> no test leakage.
    return ColumnTransformer([
        ("num", StandardScaler(), NUMERIC_COLS),
        ("cat", OrdinalEncoder(categories=[REACTION_ORDER]), [CATEGORICAL_COL]),
        ("cnt", "passthrough", [COUNT_COL]),
    ])


def make_models() -> dict:
    return {
        "logistic_regression": Pipeline([("prep", make_preprocessor()),
                                         ("clf", LogisticRegression(max_iter=1000))]),
        "random_forest": Pipeline([("prep", make_preprocessor()),
                                   ("clf", RandomForestClassifier(n_estimators=200, random_state=SEED))]),
    }


def _plot_cm(cm, name, path):
    fig, ax = plt.subplots(figsize=(4.2, 3.8))
    ax.imshow(cm, cmap="Blues")
    for (i, j), v in np.ndenumerate(cm):
        ax.text(j, i, v, ha="center", va="center", fontsize=14, color="white" if v > cm.max() / 2 else "black")
    ax.set_xticks([0, 1], ["Low (0)", "High (1)"]); ax.set_yticks([0, 1], ["Low (0)", "High (1)"])
    ax.set(xlabel="Predicted", ylabel="Actual", title=f"Confusion matrix - {name}")
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def train_and_evaluate(train: pd.DataFrame, test: pd.DataFrame, out_dir: str = OUT):
    """Fit both models on identical data, save reports (FR-1.5/1.6), pick best by test F1 (FR-1.7)."""
    fig_dir = os.path.join(out_dir, "figures")
    os.makedirs(fig_dir, exist_ok=True)
    X_tr, y_tr, X_te, y_te = train[FEATURES], train[TARGET_COL], test[FEATURES], test[TARGET_COL]
    models, metrics = make_models(), {}
    for name, model in models.items():
        model.fit(X_tr, y_tr)
        pred, score = model.predict(X_te), model.predict_proba(X_te)[:, 1]
        report = classification_report(y_te, pred, output_dict=True)
        cm = confusion_matrix(y_te, pred)
        cv_auc = cross_val_score(make_models()[name], X_tr, y_tr, cv=5, scoring="roc_auc")
        metrics[name] = {"f1": float(f1_score(y_te, pred)), "roc_auc": float(roc_auc_score(y_te, score)),
                         "cv_roc_auc_mean": float(cv_auc.mean()), "cv_roc_auc_std": float(cv_auc.std()),
                         "accuracy": float(report["accuracy"]), "precision": float(report["1"]["precision"]),
                         "recall": float(report["1"]["recall"]), "confusion_matrix": cm.tolist()}
        with open(os.path.join(fig_dir, f"classification_report_{name}.txt"), "w") as f:
            f.write(classification_report(y_te, pred))
        np.savetxt(os.path.join(fig_dir, f"confusion_matrix_{name}.csv"), cm, fmt="%d", delimiter=",")
        _plot_cm(cm, name, os.path.join(fig_dir, f"confusion_matrix_{name}.png"))
        print(f"--- {name} ---\n{classification_report(y_te, pred)}{cm}")
    best = max(metrics, key=lambda n: metrics[n]["f1"])
    meta = {"best_model": best, "feature_order": FEATURES,
            "biomarker_p75_train": float(X_tr["Biomarker_Level"].quantile(0.75)),
            "train_medians": {c: float(X_tr[c].median()) for c in NUMERIC_COLS}}
    joblib.dump({"model": models[best], "meta": meta}, os.path.join(out_dir, "risk_model.joblib"))
    pd.DataFrame({"y_true": y_te.values, "y_score": models[best].predict_proba(X_te)[:, 1]}).to_csv(
        os.path.join(out_dir, "test_predictions.csv"), index=False)
    with open(os.path.join(out_dir, "model_metrics.json"), "w") as f:
        json.dump({"selected": best, "metrics": metrics, "meta": meta}, f, indent=2)
    return models, metrics, best


def load_risk_model(path: str = f"{OUT}/risk_model.joblib"):
    bundle = joblib.load(path)
    return bundle["model"], bundle["meta"]


def score_patient(row: dict, model=None, meta=None, threshold: float = 0.5):
    """Score one raw (unscaled) patient record -> (label, probability)."""
    if model is None:
        model, meta = load_risk_model()
    p = float(model.predict_proba(pd.DataFrame([row])[FEATURES])[0, 1])
    return ("High" if p >= threshold else "Low"), p


def run(data_path: str = "data/patient_records.csv", out_dir: str = OUT):
    raw = load_raw(data_path)
    print("Missing values before cleaning:\n", raw.isnull().sum().to_string())
    clean, _, _ = impute(raw)
    assert clean.isnull().sum().sum() == 0
    clean.to_csv("data/patient_records_clean.csv", index=False)
    train_raw, test_raw = split(raw)
    train, med, mode = impute(train_raw)            # train-split statistics only
    test, _, _ = impute(test_raw, med, mode)
    models, metrics, best = train_and_evaluate(train, test, out_dir)
    test.to_csv(os.path.join(out_dir, "test_split.csv"), index=False)
    print(f"\nSelected model: {best}")
    return metrics, best


if __name__ == "__main__":
    run()
