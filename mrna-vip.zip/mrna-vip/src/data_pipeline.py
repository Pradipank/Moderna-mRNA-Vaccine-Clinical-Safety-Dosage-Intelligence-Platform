"""Module 1a - loading, validation and cleaning of patient_records.csv."""
from __future__ import annotations

import pandas as pd

REQUIRED_COLUMNS = [
    "Patient_ID", "Age", "Biomarker_Level", "Pre_Existing_Conditions",
    "Vaccine_Dose_mcg", "Prior_Reaction_History", "Reaction_Score",
]
NUMERIC_COLS = ["Age", "Biomarker_Level", "Vaccine_Dose_mcg"]
CATEGORICAL_COL = "Prior_Reaction_History"
COUNT_COL = "Pre_Existing_Conditions"
TARGET_COL = "Reaction_Score"
# Ordered categories: encoding preserves clinical severity (None < Mild < Moderate).
REACTION_ORDER = ["None", "Mild", "Moderate"]


class MissingColumnsError(ValueError):
    """Raised when the CSV lacks one or more required columns (FR-1.1)."""

    def __init__(self, missing):
        self.missing = list(missing)
        super().__init__(f"patient_records is missing required column(s): {', '.join(self.missing)}")


def load_raw(path: str) -> pd.DataFrame:
    """Load the CSV and validate the schema.

    NOTE: the literal string "None" is a *valid category* in Prior_Reaction_History
    ("no prior reaction"). pandas >= 2.0 treats "None" as NaN by default, which would
    silently turn 291 real values into "missing" and then impute them with the mode.
    We therefore disable default NA parsing and only treat empty cells as missing.
    """
    df = pd.read_csv(path, keep_default_na=False, na_values=[""])
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise MissingColumnsError(missing)
    return df


def impute(df: pd.DataFrame, medians: dict | None = None, mode: str | None = None):
    """Median-impute Biomarker_Level, mode-impute Prior_Reaction_History (FR-1.2).

    Imputation (not row removal) is used because only ~4% / ~3.5% of rows are affected
    and the dataset is small (500 rows). Pass statistics learned on the training split
    to avoid test-set leakage.
    """
    out = df.copy()
    stats = medians or {c: out[c].median() for c in NUMERIC_COLS}
    for col in NUMERIC_COLS:
        out[col] = out[col].fillna(stats[col])
    mode = mode if mode is not None else out[CATEGORICAL_COL].mode()[0]
    out[CATEGORICAL_COL] = out[CATEGORICAL_COL].fillna(mode)
    return out, stats, mode
