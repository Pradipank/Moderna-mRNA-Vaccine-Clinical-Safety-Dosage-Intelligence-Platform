"""Module 3 - chunk, embed, persist and query the regulatory guideline document.

Backends (auto-selected, same interface):
  * ChromaBackend - ChromaDB persistent collection + sentence-transformers all-MiniLM-L6-v2
                    (the PRD stack; used when both packages are installed).
  * LocalBackend  - dependency-free fallback: TF-IDF (uni+bi-grams) vectors persisted to disk.
                    Lexical, not semantic - see README limitations.
"""
from __future__ import annotations

import json
import math
import os
import re
import time
from collections import Counter

import numpy as np

PERSIST_DIR = "outputs/chroma_store"
COLLECTION = "mrna_safety_guidelines"
CHUNK_MIN, CHUNK_MAX, OVERLAP = 300, 500, 50     # tokens (FR-3.1)
CHUNK_TARGET = 350                                # preferred size; keeps chunks topically tight
EMBED_MODEL = "all-MiniLM-L6-v2"
QUERY_LOG = "outputs/rag_query_log.jsonl"

_TOKEN = re.compile(r"\w+|[^\w\s]")


def count_tokens(text: str) -> int:
    """Approximate token count (words + punctuation). Real BPE counts run ~1.2-1.3x higher."""
    return len(_TOKEN.findall(text))


def chunk_text(text: str, min_tokens: int = CHUNK_MIN, max_tokens: int = CHUNK_MAX,
               overlap: int = OVERLAP, target: int = CHUNK_TARGET) -> list[str]:
    """Sentence-aligned chunks of min..max tokens (aiming for ~target) sharing ~`overlap` tokens."""
    spans = [(m.start(), m.end()) for m in _TOKEN.finditer(text)]
    bounds = sorted({m.end() for m in re.finditer(r"(?<=[.!?])\s+|\n\s*\n", text)} | {len(text)})
    cum = [sum(1 for _, e in spans if e <= b) for b in bounds]
    chunks, start_char, start_tok, i = [], 0, 0, 0
    while i < len(bounds):
        j = i
        while j + 1 < len(bounds) and (cum[j + 1] - start_tok <= target or
                                       (cum[j] - start_tok < min_tokens and cum[j + 1] - start_tok <= max_tokens)):
            j += 1
        end_char, end_tok = bounds[j], cum[j]
        if end_char >= len(text) - 1 or j == len(bounds) - 1:
            end_char, end_tok, j = len(text), len(spans), len(bounds) - 1
        if j == len(bounds) - 1 and end_tok - start_tok < min_tokens and chunks:   # widen last chunk backwards
            start_tok = max(0, end_tok - min_tokens)
            start_char = spans[start_tok][0]
        chunks.append(text[start_char:end_char].strip())
        if j == len(bounds) - 1:
            break
        start_tok = max(0, end_tok - overlap)
        start_char = spans[start_tok][0]
        i = j + 1
    return chunks


_STOP = set("the a an of to in for and or is are be as at by on with that this it its from must should any".split())


def _terms(text: str) -> list[str]:
    words = [re.sub(r"(ing|ed|es|s)$", "", w) if len(w) > 4 else w
             for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in _STOP]
    return words + [f"{a}_{b}" for a, b in zip(words, words[1:])]


class LocalBackend:
    name = "local-tfidf"

    def build(self, chunks, persist_dir):
        df = Counter(t for c in chunks for t in set(_terms(c)))
        self.vocab = {t: i for i, t in enumerate(sorted(df))}
        n = len(chunks)
        self.idf = np.array([math.log((1 + n) / (1 + df[t])) + 1 for t in sorted(df)])
        self.chunks = chunks
        self.matrix = np.vstack([self._embed(c) for c in chunks])
        os.makedirs(persist_dir, exist_ok=True)
        np.save(os.path.join(persist_dir, "embeddings.npy"), self.matrix)
        with open(os.path.join(persist_dir, "index.json"), "w") as f:
            json.dump({"backend": self.name, "chunks": chunks, "vocab": self.vocab, "idf": self.idf.tolist()}, f)

    def load(self, persist_dir):
        with open(os.path.join(persist_dir, "index.json")) as f:
            d = json.load(f)
        self.chunks, self.vocab, self.idf = d["chunks"], d["vocab"], np.array(d["idf"])
        self.matrix = np.load(os.path.join(persist_dir, "embeddings.npy"))

    def _embed(self, text):
        v = np.zeros(len(self.vocab))
        for t, c in Counter(_terms(text)).items():
            if t in self.vocab:
                v[self.vocab[t]] = (1 + math.log(c)) * self.idf[self.vocab[t]]
        n = np.linalg.norm(v)
        return v / n if n else v

    def query(self, question, k):
        sims = self.matrix @ self._embed(question)
        order = np.argsort(-sims)[:k]
        return [self.chunks[i] for i in order], [float(sims[i]) for i in order]

    def count(self):
        return len(self.matrix)


class ChromaBackend:
    name = "chromadb+sentence-transformers"

    def __init__(self):
        import chromadb
        from sentence_transformers import SentenceTransformer
        self._chromadb, self.model = chromadb, SentenceTransformer(EMBED_MODEL)

    def _col(self, persist_dir, create=False):
        client = self._chromadb.PersistentClient(path=persist_dir)
        if create:
            try:
                client.delete_collection(COLLECTION)
            except Exception:
                pass
            return client.create_collection(COLLECTION, metadata={"hnsw:space": "cosine"})
        return client.get_collection(COLLECTION)

    def build(self, chunks, persist_dir):
        col = self._col(persist_dir, create=True)
        col.add(ids=[f"chunk-{i}" for i in range(len(chunks))], documents=chunks,
                embeddings=self.model.encode(chunks, normalize_embeddings=True).tolist())
        self.col = col

    def load(self, persist_dir):
        self.col = self._col(persist_dir)

    def query(self, question, k):
        r = self.col.query(query_embeddings=self.model.encode([question], normalize_embeddings=True).tolist(), n_results=k)
        return r["documents"][0], [1 - d for d in r["distances"][0]]

    def count(self):
        return self.col.count()


def _auto_backend(prefer: str = "auto"):
    if prefer in ("auto", "chroma"):
        try:
            return ChromaBackend()
        except Exception as e:
            if prefer == "chroma":
                raise
            print(f"[rag] ChromaDB/sentence-transformers unavailable ({type(e).__name__}); using local TF-IDF backend")
    return LocalBackend()


class GuidelineIndex:
    def __init__(self, backend: str = "auto", persist_dir: str = PERSIST_DIR, log_path: str | None = QUERY_LOG):
        self.persist_dir, self.log_path = persist_dir, log_path
        self.backend = _auto_backend(backend)
        self.chunks: list[str] = []

    @classmethod
    def build(cls, doc_path: str, **kw) -> "GuidelineIndex":
        idx = cls(**kw)
        with open(doc_path, encoding="utf-8") as f:
            idx.chunks = chunk_text(f.read())
        print(f"Split guideline document into {len(idx.chunks)} chunks (tokens: {[count_tokens(c) for c in idx.chunks]})")
        idx.backend.build(idx.chunks, idx.persist_dir)
        assert idx.backend.count() == len(idx.chunks)      # FR-3.2
        return idx

    @classmethod
    def load(cls, **kw) -> "GuidelineIndex":
        """Reload a persisted index without re-embedding (FR-3.3)."""
        idx = cls(**kw)
        idx.backend.load(idx.persist_dir)
        return idx

    def query(self, question: str, k: int = 3, purpose: str = "adhoc"):
        t0 = time.perf_counter()
        chunks, sims = self.backend.query(question, k)
        latency = max(time.perf_counter() - t0, 1e-9)
        if self.log_path:                                    # FR-3.5
            os.makedirs(os.path.dirname(self.log_path), exist_ok=True)
            with open(self.log_path, "a") as f:
                f.write(json.dumps({"question": question, "k": k, "latency_s": latency, "purpose": purpose,
                                    "backend": self.backend.name, "top_similarity": sims[0] if sims else None}) + "\n")
        return chunks, latency, sims


def query_guidelines(index: GuidelineIndex, question: str, k: int = 3):
    """Template-compatible helper: returns (chunk strings ordered by similarity, latency_s)."""
    chunks, latency, _ = index.query(question, k)
    print(f"Retrieved {len(chunks)} chunks in {latency:.4f}s")
    return chunks, latency


if __name__ == "__main__":
    store = GuidelineIndex.build("data/mrna_safety_guidelines.txt")
    for i, c in enumerate(query_guidelines(store, "What are the storage requirements below -20C?")[0], 1):
        print(f"--- Result {i} ---\n{c}\n")
